const eye_off = require('./eye-off.png');
const eye = require('./eye.png');
const google = require('./google.png');
const facebook = require('./facebook.png');
const apple = require('./apple.png');
const email = require('./email.png');
const bag = require('./bag.png');
const user = require('./user.png');
const lock = require('./lock.png');
const profile = require('./profile.jpg');
const profile1 = require('./profile1.jpg');
const back = require('./back.png');
const camera = require('./camera.png');
const tick = require('./tick.png');

export default {
  eye_off,
  eye,
  google,
  facebook,
  apple,
  email,
  bag,
  user,
  lock,
  profile,
  profile1,
  back,
  camera,
  tick,
};
